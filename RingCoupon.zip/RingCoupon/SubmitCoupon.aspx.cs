﻿using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RingCoupon
{
    public partial class SubmitCoupon : System.Web.UI.Page
    {
        public string htmlPath = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HTML_PATH"]);
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                string htmltext = System.IO.File.ReadAllText(Server.MapPath("index.html"));
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string Msg = string.Empty;
            Msg = Utility.csConfig.InsertCouponData(txtFullName.Value,txtMobile.Value,txtEmail.Value);

            txtFullName.Value = "";
            txtMobile.Value = "";
            txtEmail.Value = "";

            CreateCouponVoucher("", "", "");
        }

        public void CreateCouponVoucher(string CouponCode,string ValidFrom,string ValidTo)
        {
            string FileName = "Ring_Voucher_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".pdf";

            string htmltext = System.IO.File.ReadAllText(Server.MapPath("index.html"));
            htmlPath = htmltext.Replace("@@@couponcode@@@", CouponCode);

            StringReader sr = new StringReader(htmltext);
            Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
            using (MemoryStream memoryStream = new MemoryStream())
            {
                PdfWriter writer = PdfWriter.GetInstance(pdfDoc, memoryStream);
                pdfDoc.Open();

                htmlparser.Parse(sr);
                pdfDoc.Close();

                byte[] bytes = memoryStream.ToArray();
                memoryStream.Close();

                Response.Clear();
                Response.ContentType = "application/pdf";
                Response.AddHeader("Content-Disposition", "attachment; filename="+ FileName);
                Response.Buffer = true;
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.BinaryWrite(bytes);
                Response.End();
                Response.Close();
            }
             
            
        }
        
    }
}