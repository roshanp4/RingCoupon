﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace RingCoupon.Utility
{
    public class csConfig
    {
        public static string connString = System.Configuration.ConfigurationManager.ConnectionStrings["RC"].ConnectionString;
        public static DataTable GetSMSData_Query()
        {
            DataTable dt = new DataTable();
            string query = "select * from TEST";
            SqlConnection conn = new SqlConnection(connString);
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();

            // create data adapter
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            // this will query your database and return the result to your datatable
            da.Fill(dt);
            conn.Close();
            da.Dispose();

            return dt;
        }

        public static DataTable GetCouponData()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connString))
            {
                using (SqlCommand cmd = new SqlCommand("RC_GET_COUPON_DATA", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@FULL_NAME", SqlDbType.VarChar).Value = "";

                    con.Open();
                    // create data adapter
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    // this will query your database and return the result to your datatable
                    da.Fill(dt);
                }
            }
            return dt;
        }

        public static string InsertCouponData(string Name , string MobileNo, string Email)
        {
            string Msg = string.Empty;
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connString))
            {
                using (SqlCommand cmd = new SqlCommand("RC_INSERT_COUPON_DATA", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@FULL_NAME", SqlDbType.VarChar).Value = Name;
                    cmd.Parameters.Add("@MOBILE_NO", SqlDbType.VarChar).Value = MobileNo;
                    cmd.Parameters.Add("@EMAIL", SqlDbType.VarChar).Value = Email;

                    SqlParameter sqlParam = new SqlParameter("@RESULT", DbType.Boolean);
                    sqlParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(sqlParam);

                    SqlParameter sqlParam2 = new SqlParameter("@MSG", DbType.String);
                    sqlParam2.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(sqlParam2);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    Msg = cmd.Parameters["@RESULT"].Value.ToString();
                }
            }
            return Msg;
        }

        public static bool RCLogin(string UserID, string Password)
        {
            bool Value = false;
            using (SqlConnection con = new SqlConnection(connString))
            {
                using (SqlCommand cmd = new SqlCommand("SMS_LOGIN", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@USER_ID", SqlDbType.VarChar).Value = UserID;
                    cmd.Parameters.Add("@PWD", SqlDbType.VarChar).Value = Password;

                    SqlParameter sqlParam = new SqlParameter("@IS_SUCCESS", DbType.Boolean);
                    sqlParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(sqlParam);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    var Val = cmd.Parameters["@IS_SUCCESS"].Value.ToString();

                    if (Val == "1") Value = true;

                }
            }

            return Value;
        }
    }
}